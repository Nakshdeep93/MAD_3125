package com.example.macstudent.login;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CarCompanyAdaptor extends BaseAdapter {

    int[] logos;
    String[] companyName;
    Context Context;
    LayoutInflater inflater;

    CarCompanyAdaptor(Context Context, int[] logos,String[] companyNames){
        this.logos =logos;
        this.companyName= companyNames;
        this.Context = Context;
        inflater= LayoutInflater.from(Context);

    }
    @Override
    public int getCount() {
        return companyName.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        convertView = inflater.inflate(R.layout.carcompany_spinner_item,null);

        ImageView imgLogo= convertView.findViewById(R.id.img_logo);
        TextView txtCompany = convertView.findViewById(R.id.txtcompany);

        imgLogo.setImageResource(this.logos[position]);
        txtCompany.setText(this.companyName[position]);
        return convertView;
    }


}
