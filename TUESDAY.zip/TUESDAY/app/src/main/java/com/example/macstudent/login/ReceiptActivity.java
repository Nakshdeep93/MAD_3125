package com.example.macstudent.login;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ReceiptActivity extends AppCompatActivity {

    TextView txtDateTime, txtAmount,txtlot,txtSpot,txtCarPlate;

    public void onBackPressed(){
        startActivity(new Intent(getApplicationContext(),HomeActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);
        SharedPreferences sp= getSharedPreferences("com.example.macstudent.login.shared", Context.MODE_PRIVATE);

        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(sp.getString("DateTime","Date missing"));

        txtCarPlate = findViewById(R.id.txtCarPlate);
        txtCarPlate.setText(sp.getString("car plate","data missing"));

        txtlot = findViewById(R.id.txtLot);
        txtlot.setText(sp.getString("lot","data missing"));

        txtSpot = findViewById(R.id.txtSpot);
        txtSpot.setText(sp.getString("spot","data missing"));

        txtAmount =findViewById(R.id.txtAmount);
        txtAmount.setText(sp.getString("Amount","data missing"));
    }
}
